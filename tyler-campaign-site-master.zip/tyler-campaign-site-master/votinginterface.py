f = "1"
while f == "1":
  a = input("click y for voting for me type n if your not")
  if a == "y":
    print("thankyou for voting for tyler")
  if a == "y":
    print("thank you for taing the poll we hope we can change your mind on the decision")
  else:
    print("an error occord when trying to register your vote please check that caps lock is off and ty again")
    f = "1"
